First, Update Bot
1. Replace your current bot executable with content of "bot" folder
2. place "chats" folder under C:\
3. Make sure bot\botconfig.txt has the current token value
4. start the bot

Second, Make the following tests
1. shut down bot to make changes every time
2. all changes should be made in folder chats\miner
2. make changes for yourself in minerstat and test with \coin
3. change item description in shopitems and test with \item
4. add lines in specialblock and test

Complete!
Third round requires Visual Studio 2017 Express
I'll look for solutions if there is a problem
I inlcuded the install program in this package