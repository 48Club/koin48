﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nano.Club.Miner;

namespace Nano.Club.ThirdParty
{
    /// <summary>
    /// This is how you create a new item type
    /// Clone and TypeName functions need to be overriden
    /// All other functions are optional
    /// </summary>
    public class SampleItem : Miner.ShopItemBase
    {

        public override ShopItemBase Clone()
        {
            return new SampleItem();
        }

        public override string TypeName()
        {
            return "sample";
        }


        //the folllowing two functions make the item usable
        public override bool CanUse()
        {
            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="master">API Entry Point</param>
        /// <param name="user">sender of the message</param>
        /// <param name="target">replyto if any</param>
        /// <returns>Bot will display the return string</returns>
        public override string UseItem(Miner.Miner master, string user, string target)
        {
            //Get All Status of the user
            Miner.MinerStat stat = master.GetStat(user);
            if (stat == null)
                return null;  //stat should never be null, just in case



            //Example One Give the User ten shitcoins
            uint receiveitem = 1002;
            stat.ChangeAmount(receiveitem, 10, true);
            //uncomment this if you want the item to be spent on use
            //stat.ChangeAmount(this.ID(), -1, true);

            //Example Two Acquire the info of item 1002
            ShopItemBase item = master.GetInventory().GetItem(receiveitem.ToString());

            //Example Three Save the result 
            master.WriteBalance();

            //Example Four have the bot say something
            //master.GetName tries to return the name in order: 1. NickName, 2. User Name 3. USERID
            //      In case some are null
            
            string rtn = string.Format("{0} uses {1} to get {2}", master.GetName(user), this.GetSymbol(), item.GetSymbol());
            return rtn;

        }
    }
}
