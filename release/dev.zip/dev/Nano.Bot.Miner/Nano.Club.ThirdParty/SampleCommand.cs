﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nano.Club.Miner;

namespace Nano.Club.ThirdParty
{
    /// <summary>
    /// This create a bot command
    /// Four functions must be overriden (abstract)
    ///     ExecuteCommand, GetDescription,GetGasCost,GetCommand
    /// </summary>
    public class SampleCommand : Miner.BaseMinerCommand
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="input">Input from the chat group</param>
        /// <returns>result instructs what bot will do</returns>
        public override MinerResult ExecuteCommand(MinerInput input)
        {
            //Example - Save the balance
            master.WriteBalance();


            //Return for the bot
            MinerResult result = new MinerResult();
            result.chatid = input.chatid;  //which chat group the bot will display the message
            result.result = "My Command Test"; //this is what bot will say

            return result;
        }

        public override string GetDescription()
        {
            return "This is a test Command"; //this will be displayed if someone uses "/mine"
        }

        public override decimal GetGasCost()
        {
            return 0; //free
        }

        public override string GetCommand()
        {
            return "/sample";
        }
    }
}
