﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Telegram.Bot.Args;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.InlineQueryResults;
using Telegram.Bot.Types.ReplyMarkups;

namespace Nano.Bot.Miner
{
    public class BotEngine
    {
        Telegram.Bot.TelegramBotClient bot;
        BotEngineConfig config;
        static Telegram.Bot.Types.User me;
        List<long> chatrooms = new List<long>();
        System.IO.StreamWriter writer;
        Nano.Club.Miner.Miner miner;
        int lastmessageid = 0;

        public void Init()
        {
            writer = new System.IO.StreamWriter("c://chats//record.txt", true);
            miner = new Club.Miner.Miner();
            miner.Init();


            Nano.Common.Reflection.ConfigReader reader = new Common.Reflection.ConfigReader();
            config = reader.LoadItemT<Nano.Bot.Miner.BotEngineConfig>("./botconfig.txt");
            bot = new Telegram.Bot.TelegramBotClient(config.token);
            me = bot.GetMeAsync().Result;
            
            bot.StartReceiving(Array.Empty<UpdateType>());
            bot.OnMessage += Bot_OnMessage;
            bot.OnInlineQuery += Bot_OnInlineQuery;
            bot.OnUpdate += Bot_OnUpdate;

            Console.WriteLine("Mining Bot Started");
           
        }

        private void Bot_OnUpdate(object sender, UpdateEventArgs e)
        {
            if (e.Update.Type == UpdateType.CallbackQuery)
            {
                Console.WriteLine(e.Update.CallbackQuery.Data);
            }
        }

        private void Bot_OnInlineQuery(object sender, InlineQueryEventArgs e)
        {
            Console.WriteLine("INLINE: " + e.InlineQuery);
        }

        private void Bot_OnMessage(object sender, MessageEventArgs e)
        {
            if (!CanProcessMessage(e))
                return;

         

            string username = "";
            Telegram.Bot.Types.User user = e.Message.From;
            if (user != null)
                username = string.Format("{0} {1}", user.FirstName, user.LastName);
         
            long chatid = e.Message.Chat.Id;
            int msgid = e.Message.MessageId;
            string replyuserid = null;
            Telegram.Bot.Types.User replyuser = null;
            if (e.Message.ReplyToMessage != null)
            {
                
                replyuser = e.Message.ReplyToMessage.From;
                replyuserid = replyuser.Id.ToString();
            }

            Nano.Club.Miner.MinerInput input = new Nano.Club.Miner.MinerInput();

            input.chatid = chatid;
            input.initiator = user.Id.ToString();
            input.initiatorname = username;
            if (replyuser != null && replyuser.IsBot)
            {
                input.replyto = null;
            }
            else
                input.replyto = replyuserid;

            input.text = e.Message.Text;
            input.msgid = e.Message.MessageId;

            Nano.Club.Miner.MinerResult res = miner.TryExecuteCommand(input);
            if (res != null)
            {

                if (res.result != null && res.keys == null)
                {
                    string stext = string.Format("{0}", res.result);
                    PostMessage(chatid, stext, 0);
                }

                if (res.secretmessage != null)
                {
                    PostMessage(user.Id, res.secretmessage, 0);
                }

                if (res.keys != null)
                {
                    PostKeyBoard(res);
                   
                    return;
                }

                
            }
            return;

          
        }

        bool CanProcessMessage(MessageEventArgs e)
        {
            if (e.Message.MessageId == lastmessageid)
                return false;
            lastmessageid = e.Message.MessageId;
            TimeSpan span = DateTime.Now.ToUniversalTime() - e.Message.Date.ToUniversalTime();
            if (span.TotalMilliseconds > 150000)
                return false;
            if (e.Message == null)
                return false;
            if (e.Message.Text == null)
                return false;

            return true;
        }
        void LogAndDisplay(MessageEventArgs e)
        {
            string username = null;
            Telegram.Bot.Types.User user = e.Message.From;
            if (user != null)
                username = string.Format("{0} {1}", user.FirstName, user.LastName);

            Console.WriteLine(e.Message.Text);
            writer.Write(e.Message.Chat.Id.ToString());
            writer.Write(":");
            writer.Write(e.Message.Chat.Title);
            writer.Write(":");
            writer.Write(username);
            writer.Write(":");
            writer.Write(e.Message.From.Id);
            writer.Write(":");
            writer.WriteLine(e.Message.Text);
            writer.Flush();
        }
        void PostKeyBoard(Nano.Club.Miner.MinerResult res)
        {
            List<KeyboardButton[]> allrows = new List<KeyboardButton[]>();
            List<KeyboardButton> current = null;
            for (int i = 0; i < res.keys.Length; i++)
            {
                if (current == null)
                {
                    current = new List<KeyboardButton>();
                }

                KeyboardButton button = new KeyboardButton(res.keys[i]);
                current.Add(button);

                if (i % 3 == 2 || i == res.keys.Length - 1)
                {
                    allrows.Add(current.ToArray());
                    current = null;
                }
            }
            ReplyKeyboardMarkup ikm = new ReplyKeyboardMarkup(allrows.ToArray());
            bot.SendTextMessageAsync(res.chatid, res.result, replyMarkup: ikm);

        }
        void PostMessage(long chatid, string msg, int msgid)
        {

            if (msgid == 0)
                bot.SendTextMessageAsync(chatid, msg, 0);
            else
            {
                bot.SendTextMessageAsync(chatid, msg, disableNotification: true, replyToMessageId: msgid);
            }
            Console.WriteLine("BOT: " + msg);

            return;
          
        }

        public void Fini()
        {

        }
    }
}
