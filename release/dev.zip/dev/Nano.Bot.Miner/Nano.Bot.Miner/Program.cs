﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;




namespace Nano.Bot.Miner
{
    class Program
    {
        static void Main(string[] args)
        {

            BotEngine engine = new BotEngine();
            engine.Init();
            Console.ReadLine();
            engine.Fini();



        }
    }
}
