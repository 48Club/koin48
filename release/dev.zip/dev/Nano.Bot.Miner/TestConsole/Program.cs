﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConsole
{
    internal class FakeUser
    {
        internal long chatid = 1001;
        internal string userid;
        internal string name;

        public FakeUser(long chatid, string userid, string name)
        {
            this.chatid = chatid;
            this.userid = userid;
            this.name = name;
        }
    }
    class Program
    {
        static Nano.Club.Miner.Miner miner = new Nano.Club.Miner.Miner();
        static void chat(FakeUser sender, FakeUser replyto, string text)
        {
            Nano.Club.Miner.MinerInput input = new Nano.Club.Miner.MinerInput();
            input.chatid = sender.chatid;
            input.initiator = sender.userid;
            input.initiatorname = sender.name;
            if (replyto != null)
                input.replyto =replyto.userid;
            input.text = text;
            Nano.Club.Miner.MinerResult res = miner.TryExecuteCommand(input);
            if (res == null)
                return;
            Console.WriteLine(res);
            if (res.secretmessage != null)
            {
                Console.WriteLine(res.secretmessage);
            }
        }

        static void Main(string[] args)
        {
            Console.WriteLine("club miner");
            //NEVER REMOVE THIS LINE!
            Nano.Club.Miner.Localization.MinerPath = "C:/chats/miningtest/";
            miner.Init();

            //Create Some People, use same chatid, unique userid and unique names
            FakeUser Joe = new FakeUser(1001, "12345", "JOE");
            FakeUser Bob = new FakeUser(1001, "12346", "BOB");

            //Example of Chatting, Create your user scripts here
            chat(Joe,null, "hhhhhhhh");
            chat(Bob, null, "/shop");
            chat(Joe, null, "/coin");
            chat(Bob, Joe, "/tip 1");

            //Test Lines for new command and item

            //Sample Command
            chat(Bob, null, "/sample");
            //Sample Item
            chat(Bob, null, "/use 3333");
            //check balance after using item
            chat(Bob, null, "/coin");
            Console.ReadLine();
            
        }
    }
}
