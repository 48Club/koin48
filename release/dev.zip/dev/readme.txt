1. install vs express, you can use the one in this package, or download your own, if download, make sure scroll down on MS website, and get the express instead of community
2. place the "minertest" folder in your C:/chats folder, in parallel with "miner" folder
3. in Nano.bot.miner/bin/debug place your bot token in the config file, like before


4. Start the solution in Nano.bot.miner folder (the root one)
5. you will see three projects, the bot project, the test console, and a sample project (Nano.club.thirdparty)
6. test console uses the minertest folder, and bot uses the old miner folder.
7. run the test console to see how it works.  there are explainations in the program->main function
8. The sample project is for you to modify or add items/commands into the system, run testconsole first to test, then run the bot to see if it works
9. Make some changes to the samplecommand
10. The sample item is linked to the one in shopitem.txt, very last line. "typename" here has to match the typename in the class to work properly
	You can modify this one or add a new class with a new type
11. demonstrate your creativity in the dev room

