1. Create a bot at telegram botfather
2. Disable privacy of the bot
3. rename the bot in a way that it's obviously yours
4. bring the bot to BNB48 Club DEV Chatroom
5. in botconfig.txt->token, replace the value with your bots' token
6. Run the app
7. The first time someone say something in chatroom, bot should say"Found Chatroom xxxxxx"
8. Due UTC Time 8/8 0:00am